"""
Define and implement the FileFinder class.
"""
import os


class FileFinder:

    def __init__(self, search_root):
        """
        Create a new FileFinder instance.

        Args:
            search_root: a string representing the top-level directory of the
                search.
        """
        pass  # FILL THIS IN

    def find(self, file_name):
        """
        Find and return a list of paths rooted at search_root whose names
        match file_name.

        Examine all files rooted at search_root (that is, files in
        search_root or any of its descendant subdirectories) and find the
        paths of all files whose name exactly matches file_name. For the
        purposes of matching, directory names do not count (so the "/usr/bin"
        directory would not show up in a search for "bin").

        Any errors encountered while searching for files (e.g., getting a
        permission denied error) are be silently ignored, and execution
        will proceed without any such files being returned.

        Args:
            file_name: a string representing the name of the file to find.

        Returns:
            A list of file paths matching file_name. If no files in the
            directory tree match, return an empty list.
        """
        return []  # FILL THIS IN
